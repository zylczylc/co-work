#!/bin/bash
marco(){
	export MARCO_DIR=$(pwd)
}
polo(){
	cd "$MARCO_DIR" || return 1
}
